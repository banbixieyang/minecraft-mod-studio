package com.example.samplemod;

public class SampleModClient {
    public void onInitializeClient() {
        // 样本 mod 的客户端入口
    }
}
