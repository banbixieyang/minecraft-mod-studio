package com.example.samplemod;

public class SampleMod {
    public static final String MOD_ID = "samplemod";

    public void onInitialize() {
        // 样本 mod 的入口
    }
}
